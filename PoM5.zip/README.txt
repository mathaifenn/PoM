Patterns of the Mind — static site (phone-first, no JS)
======================================================

Open index.html locally to preview. Replace images per page:
assets/img/placeholder.jpg -> your actual images.

Deployment note:
- Works offline and on Netlify/GitHub Pages without a build step.
- Left navigation becomes a sticky sidebar on wide screens.

Editing:
- All copy is taken *word for word* from `Pom Content.md` sections 1–7.
- `setting.html` shows a centered button for “See Fenn Hall on Google Maps”. Edit its href.

Structure:
See the commented block at the top of each HTML file for the recommended folders.